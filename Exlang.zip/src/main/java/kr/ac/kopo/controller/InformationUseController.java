package kr.ac.kopo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/InformationUse")
public class InformationUseController {
	final String path = "InformationUse/";
		
		@RequestMapping("/info")
			String info() {
			return path + "info";
		}
			
}

