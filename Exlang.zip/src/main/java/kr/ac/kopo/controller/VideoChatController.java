package kr.ac.kopo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/VideoChat")
public class VideoChatController {
	final String path = "VideoChat/";
		
		@RequestMapping("/chat")
			String chat() {
			return path + "chat";
		}
			
}
