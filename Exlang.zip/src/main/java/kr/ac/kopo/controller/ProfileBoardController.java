package kr.ac.kopo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.kopo.model.ProfileBoard;
import kr.ac.kopo.service.ProfileBoardService;

@Controller
@RequestMapping("/ProfileBoard")
public class ProfileBoardController {
		
	@Autowired
	ProfileBoardService service;
	
	@RequestMapping("/list")
		String list(Model model) {
		List<ProfileBoard> list = service.getList();
		model.addAttribute("list",list);
			return  "/ProfileBoard/board";
		
		}
		
		
		
		
			
}
