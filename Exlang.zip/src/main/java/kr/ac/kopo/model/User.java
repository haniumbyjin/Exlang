package kr.ac.kopo.model;

//JSP(클라이언트의 요청) ->컨트롤러 -> 서비스 -> 서비스 impl -> Dao ->DaoImp -> Mybatis(맵퍼)
//erd에 있는 내용담기.
public class User {
	String userId;
	String userPw;
	String userName;
	String userNl;
	String userPl;
	String userHobby;
	String userAuthority;
	String userIntro;
	int userAge;
	char userSex;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPw() {
		return userPw;
	}
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserNl() {
		return userNl;
	}
	public void setUserNl(String userNl) {
		this.userNl = userNl;
	}
	public String getUserPl() {
		return userPl;
	}
	public void setUserPl(String userPl) {
		this.userPl = userPl;
	}
	public String getUserHobby() {
		return userHobby;
	}
	public void setUserHobby(String userHobby) {
		this.userHobby = userHobby;
	}
	public String getUserAuthority() {
		return userAuthority;
	}
	public void setUserAuthority(String userAuthority) {
		this.userAuthority = userAuthority;
	}
	public String getUserIntro() {
		return userIntro;
	}
	public void setUserIntro(String userIntro) {
		this.userIntro = userIntro;
	}
	public int getUserAge() {
		return userAge;
	}
	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}
	public char getUserSex() {
		return userSex;
	}
	public void setUserSex(char userSex) {
		this.userSex = userSex;
	}
	
}
