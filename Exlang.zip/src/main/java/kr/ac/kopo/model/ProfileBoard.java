package kr.ac.kopo.model;

public class ProfileBoard {
	int pNum;
	String pIntro;
	int pDate;
	String userId;
	
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public String getpIntro() {
		return pIntro;
	}
	public void setpIntro(String pIntro) {
		this.pIntro = pIntro;
	}
	public int getpDate() {
		return pDate;
	}
	public void setpDate(int pDate) {
		this.pDate = pDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

}
