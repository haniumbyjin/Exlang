package kr.ac.kopo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.dao.ProfileBoardDao;
import kr.ac.kopo.model.ProfileBoard;

@Service
public class ProfileBoardServiceImpl implements ProfileBoardService {

	@Autowired
	ProfileBoardDao dao;
	
	@Override
	public List<ProfileBoard> getList() {
		return dao.getList();
	}

}
