package kr.ac.kopo.service;

import java.util.List;

import kr.ac.kopo.model.ProfileBoard;

public interface ProfileBoardService {

	List<ProfileBoard> getList();

}
