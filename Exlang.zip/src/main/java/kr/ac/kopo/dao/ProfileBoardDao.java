package kr.ac.kopo.dao;

import java.util.List;

import kr.ac.kopo.model.ProfileBoard;

public interface ProfileBoardDao {

	List<ProfileBoard> getList();

}
